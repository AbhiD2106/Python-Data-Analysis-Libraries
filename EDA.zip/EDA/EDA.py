import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

train = pd.read_csv(r'E:\my_work\Python_libs\Python-Data-Analysis-Libraries\EDA\train.csv')
print(train)
print(train.columns)


print("\n",train['Age'].describe())


train['Age'].plot(kind='hist', bins=20  )

plt.title('Age Distribution')
plt.xlabel('Age')
plt.ylabel('Frequency')

plt.show()